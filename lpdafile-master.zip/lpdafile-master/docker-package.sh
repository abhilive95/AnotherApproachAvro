#!/bin/sh

export REG_BASE_URI="NE1ITCPRHAS62.ne1.savvis.net:4567";
export REG_PROJECT="/chatsvcs_dev/lpdafile"
export REG_IMAGE="${REG_BASE_URI}${REG_PROJECT}:latest";

#get the jar to be deployed.
#variable are set in GOCD pipeline environment.

echo "*** Getting jar from ${NEXUS_URL}";
mkdir -p target;
curl -v -u hyperion:${NEXUS_PWD} -o target/${TARGET}-${VERSION}-SNAPSHOT.war ${NEXUS_URL}/${TARGET}/${VERSION}/${TARGET}-${VERSION}-SNAPSHOT.war;

#build and push the docker image to your registry
#REG_TOKEN should be set in secret GOCD variable
echo "*** Building and pushing docker image to registry ${REG_BASE_URI}";
docker login -u gitlab-ci-token -p ${REG_TOKEN} ${REG_BASE_URI};
docker build -t ${REG_IMAGE} .;
docker push ${REG_IMAGE};