package com.centurylink.security.jwt;

import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import com.centurylink.liveperson.exception.InvalidJwtException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwsHeader;
import io.jsonwebtoken.Jwts;

@Component(value="jwtSecurityProcessor")
public class JWTSecurityProcessor implements Processor {
	
	final String KEYFACTORY="RSA";
	final String JWT_TYPE="JWT";
	final String JWT_ALGORITHM="RS256";

	@Override
	public void process(Exchange exchange) throws Exception {
		
		String bearerToken = exchange.getIn().getHeader("Authorization", String.class);
		if (bearerToken == null || !bearerToken.startsWith("Bearer ")) {
            throw new InvalidJwtException("No JWT token found in request headers");
        }

		// strip out just the JWT
        String jwtToken = bearerToken.substring(7);
        
        // get the CXG7 exchange properties that are used to verify the JWT
        String pubKeyString = exchange.getProperty("cxg7.jwt.pubkey").toString();
        String issuerString = exchange.getProperty("cxg7.jwt.claim.iss").toString();
        String subjectString = exchange.getProperty("cxg7.jwt.claim.sub").toString();
		
    	byte[] publicBytes = Base64.getDecoder().decode(pubKeyString.getBytes());
    	X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
    	KeyFactory keyFactory = KeyFactory.getInstance(KEYFACTORY); 
    	PublicKey pubKey = keyFactory.generatePublic(keySpec);

       	// check JwsHeader for presence of type and algorithm
		@SuppressWarnings("rawtypes")
		final JwsHeader jwsHeader = Jwts.parser().setSigningKey(pubKey).parseClaimsJws(jwtToken).getHeader();
       	String jwtType = jwsHeader.getType();
       	String jwtAlgorithm = jwsHeader.getAlgorithm();
       	if(! ((jwtType.equals(JWT_TYPE)) && (jwtAlgorithm.equals(JWT_ALGORITHM))) ) {
       		throw new InvalidJwtException("Invalid JWT Type or Algorithm");
       	}
       	
       	final Claims claims = Jwts.parser().setSigningKey(pubKey).parseClaimsJws(jwtToken).getBody();
      
       	String issuer = claims.getIssuer();
       	String subject = claims.getSubject();
       	if(! ((issuer.equals(issuerString)) && (subject.equals(subjectString)))) {
       		throw new InvalidJwtException("Invalid JWT Issuer or Subject");
       	}

    	// pass standard JWT Claims along as exchange properties
       	exchange.setProperty("jwt.claim.id",claims.getId());
       	exchange.setProperty("jwt.claim.issuedat",claims.getIssuedAt());
       	exchange.setProperty("jwt.claim.expiration",claims.getExpiration());
       	exchange.setProperty("jwt.claim.issuer", issuer);
       	exchange.setProperty("jwt.claim.subject", subject);
       	
       	// pass any custom JWT Claims you need to along as exchange properties
       	
       	
	}

}
