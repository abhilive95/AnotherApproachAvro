package com.centurylink.liveperson.security;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.BASE64Encoder;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;


public class OAuthSignatureProcessor2 implements Processor {

	// https://oauth.net/core/1.0/#signing_process
	// https://dev.twitter.com/oauth/overview/creating-signatures
	// https://developers.liveperson.com/guides-gettingstarted.html
	// https://developers.liveperson.com/data-data-access-overview.html

	
	
    private static String consumerKey = "58876892f76649548095075ab206cccb";
    private static String consumerSecret = "2893e698038e88c1";

    private static String token= "37e714c0bcc043088f2d22c2d49ed508";
    private static String tokenSecret = "7347248ddfc6b56b";
    
    private static final String HMAC_SHA1 = "HmacSHA1";

    private static final String ENC = "UTF-8";

    private static Base64 base64 = new Base64();

    
	public void process(Exchange ex) throws Exception {
		
		//ex.getIn().setHeader("Content-Type", "application/x-www-form-urlencoded");
		String nonce =  "" + (int) (Math.random() * 100000000);
		String timeStamp = "" + (System.currentTimeMillis() / 1000);
		String oauth = "OAuth oauth_consumer_key=\"" + consumerKey;
		oauth += "\", oauth_token=\"" + token;
		oauth += "\", oauth_signature_method=\"HMAC-SHA1";
		oauth += "\", oauth_timestamp=\"" + timeStamp + "\"";
		oauth += ", oauth_nonce=\"" + nonce;
		oauth += "\", oauth_version=\"1.0\"";		
		oauth += ", oauth_signature=\"" + getOAuthSignature(nonce, timeStamp) + "\"";

		ex.getIn().setHeader("Authorization", oauth);
		
	}
    
    
    
    
    /**
     * 
     * @param url
     *            the url for "request_token" URLEncoded.
     * @param params
     *            parameters string, URLEncoded.
     * @return
     * @throws UnsupportedEncodingException
     * @throws NoSuchAlgorithmException
     * @throws InvalidKeyException
     */
    private String getSignature(String url, String params)
            throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
        /**
         * base has three parts, they are connected by "&": 1) protocol 2) URL
         * (need to be URLEncoded) 3) Parameter List (need to be URLEncoded).
         */
        StringBuilder base = new StringBuilder();
        base.append("GET&");
        base.append(url);
        base.append("&");
        base.append(params);
        System.out.println("Stirng for oauth_signature generation:" + base);
        // yea, don't ask me why, it is needed to append a "&" to the end of
        // secret key.
        byte[] keyBytes = (consumerSecret).getBytes(ENC);
        
        byte[] tokenBytes =(tokenSecret).getBytes(ENC);
        
        String signingKey = keyBytes.toString() + "&" + tokenBytes.toString();

        SecretKey key = new SecretKeySpec(signingKey.getBytes(), HMAC_SHA1);

        Mac mac = Mac.getInstance(HMAC_SHA1);
        mac.init(key);

        // encode it, base64 it, change it to string and return.
        return new String(base64.encode(mac.doFinal(base.toString().getBytes(ENC))), ENC).trim();
    }	
	
	
	private String getOAuthSignature(String nonce, String timeStamp) throws InvalidKeyException, UnsupportedEncodingException, NoSuchAlgorithmException {
		
		
		//String oauth_consumer_key;
		//String oauth_nonce;
		//String oauth_signature_method;
		//String oauth_timestamp;
		//String oauth_token;
		//String oauth_version;

		
		List<NameValuePair> qparams = new ArrayList<NameValuePair>();
        // These qparams should be ordered by key
		//qparams.add(new BasicNameValuePair("endTime", "1501857590"));
        qparams.add(new BasicNameValuePair("oauth_consumer_key", consumerKey));
        qparams.add(new BasicNameValuePair("oauth_nonce", nonce));
        qparams.add(new BasicNameValuePair("oauth_signature_method", "HMAC-SHA1"));
        qparams.add(new BasicNameValuePair("oauth_timestamp", timeStamp));
        qparams.add(new BasicNameValuePair("oauth_token", token));
        qparams.add(new BasicNameValuePair("oauth_version", "1.0"));
        //qparams.add(new BasicNameValuePair("startTime", "1501846790"));
        
        // generate the oauth_signature
        String signature = getSignature(URLEncoder.encode(
                "https://va.da.liveperson.net/data_access_le/account/43906703/le", ENC),
                URLEncoder.encode(URLEncodedUtils.format(qparams, ENC), ENC));
		
		return signature;
	}

	
	/**
	    * percentage encoding
	    *
	    * @return A encoded string
	    */
	 private String encode(String value) {  
	     String encoded = "";  
	     try {  
	       encoded = URLEncoder.encode(value, "UTF-8");  
	     } catch (Exception e) {  
	       e.printStackTrace();  
	     }  
	      String sb = "";  
	     char focus;  
	     for (int i = 0; i < encoded.length(); i++) {  
	       focus = encoded.charAt(i);  
	       if (focus == '*') {  
	         sb += "%2A"; 
	       } else if (focus == '+') {  
	         sb += "%20";
	       } else if (focus == '%' && i + 1 < encoded.length()  
	           && encoded.charAt(i + 1) == '7' && encoded.charAt(i + 2) == 'E') {  
	         sb += '~';
	         i += 2;  
	       } else {  
	         sb += focus;
	       }  
	     }  
	     return sb.toString();  
	   }  
	 
	private String generateSignature(String signatueBaseStr, String oAuthConsumerSecret, String oAuthTokenSecret) {  
	     byte[] byteHMAC = null;  
	     try {  
	       Mac mac = Mac.getInstance("HmacSHA1");  
	       SecretKeySpec spec;  
	       if (null == oAuthTokenSecret) {  
	         String signingKey = encode(oAuthConsumerSecret) + '&';  
	         spec = new SecretKeySpec(signingKey.getBytes(), "HmacSHA1");  
	       } else {  
	         String signingKey = encode(oAuthConsumerSecret) + '&' + encode(oAuthTokenSecret);  
	         spec = new SecretKeySpec(signingKey.getBytes(), "HmacSHA1");  
	       }  
	       mac.init(spec);  
	       byteHMAC = mac.doFinal(signatueBaseStr.getBytes());  
	     } catch (Exception e) {  
	       e.printStackTrace();  
	     }  
	     return new BASE64Encoder().encode(byteHMAC);  
	   }  
	
	
}
