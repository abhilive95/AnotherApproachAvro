package com.centurylink.liveperson.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class Http403ForbiddenProcessor implements Processor {

	public void process(Exchange ex) throws Exception {
		
		ex.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 403);
		ex.getIn().setBody(null);
		
	}

}
