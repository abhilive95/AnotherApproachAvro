package com.centurylink.liveperson.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.http.common.HttpOperationFailedException;

import com.centurylink.hyperion.sentry.SentryAlarm;
import com.centurylink.liveperson.utility.LpdaFileConstants;

import sentry.event.Severity;

public class LogEventProcessor implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {

		HttpOperationFailedException hofe = exchange.getProperty(Exchange.EXCEPTION_CAUGHT,
				HttpOperationFailedException.class);
		String exceptionType = exchange.getProperty("exceptionType").toString();
		Severity severity = Severity.WARNING;
		String app = LpdaFileConstants.APP_NAME;
		String subSystem = LpdaFileConstants.SUBSYSTEM_NAME;
		int identifier = LpdaFileConstants.DEFAULT_IDENTIFIER;
		String eventObject = "LivePersonRouteBuilder";
		String eventMessage = "Internal Server Error";
		String classInfo = "";
		
		switch (exceptionType) {
		case LpdaFileConstants.SOCKET_TIMEOUT_EXCEPTION:
			severity = Severity.MAJOR;
			identifier = LpdaFileConstants.SOCKET_TIMEOUT_EXCEPTION_IDENTIFIER;
			eventMessage = "Endpoint NOT responding in time";
			break;
			
		case LpdaFileConstants.TRANSPORT_EXCEPTION:
			severity = Severity.CRITICAL;
			identifier = LpdaFileConstants.TRANSPORT_IDENTIFIER;
			eventMessage = "Issue while connecting to the Endpoint";
			break;

		case LpdaFileConstants.FILENOTFOUND_EXCEPTION:
			severity = Severity.MAJOR;
			identifier = LpdaFileConstants.FILENOTFOUND_IDENTIFIER;
			eventMessage = "File not found";
			break;

		case LpdaFileConstants.OUTOFMEMORY_EXCEPTION:
			severity = Severity.CRITICAL;
			identifier = LpdaFileConstants.OUTOFMEMORY_IDENTIFIER;
			eventMessage = "system ran out of memory";
			break;

		case LpdaFileConstants.HTTP_OPERATIONFAILED_EXCEPTION:
			severity = Severity.MAJOR;
			identifier = LpdaFileConstants.HTTP_OPERATIONFAILED_IDENTIFIER;
			eventMessage = getEventMessage(hofe.getStatusCode());
			break;

		case LpdaFileConstants.IO_EXCEPTION:
			severity = Severity.MINOR;
			identifier = LpdaFileConstants.IO_IDENTIFIER;
			eventMessage = "generic ioexception";
			break;

		case LpdaFileConstants.FILE_OPERATIONFAILED_EXCEPTION:
			severity = Severity.CRITICAL;
			identifier = LpdaFileConstants.FILE_OPERATIONFAILED_IDENTIFIER;
			eventMessage = "File processing failed";
			break;
			
		case LpdaFileConstants.FILE_SOCKET_EXCEPTION:
			severity = Severity.CRITICAL;
			identifier = LpdaFileConstants.FILE_SOCKET_EXCEPTION_IDENTIFIER;
			eventMessage = "ftp socket error";
			break;
			
		default:
			severity = Severity.UNKNOWN;
			identifier = LpdaFileConstants.DEFAULT_IDENTIFIER;
			eventMessage = "unknown exception occured";
			break;
		}

		SentryAlarm.sendEvent(severity, app, subSystem, identifier, eventObject, eventMessage, classInfo);

	}

	private String getEventMessage(int statusCode) {
		String message = "";
		switch (statusCode) {
		case 400:
			message = "Bad request, please check the logging console for more info";
			break;
		case 401:
			message = "Unauthorized request";
			break;
		case 404:
			message = "No Available Files";
			break;
		case 503:
			message = "Service Unavailable";
			break;
		default:
			message = "Internal Server Error";
			break;
		}
		return message;
	}

}
