package com.centurylink.liveperson.processor;

import com.liveperson.dataaccess.DataaccessRoot;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.specific.SpecificDatumReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Created by Liveperson on 4/24/2016.
 */
public class DASchemaUtils {
    private static final Logger LOG = LoggerFactory.getLogger(DASchemaUtils.class);

    /**
     * create DataaccessRoot specific record (pojo) from json
     *
     * @param schemaWriterJson - the schema that the event was written with
     * @param json
     * @return
     */
    public static DataaccessRoot fromJsonToSpecific(String json, String schemaWriterJson) throws IOException {
        Schema schemaWriter = new org.apache.avro.Schema.Parser().parse(schemaWriterJson);
        DataaccessRoot dataaccessRoot = null;

        try {
            Decoder decoder = DecoderFactory.get().jsonDecoder(schemaWriter, json);
            DatumReader<DataaccessRoot> reader = new SpecificDatumReader<DataaccessRoot>(schemaWriter, DataaccessRoot.SCHEMA$);

            dataaccessRoot = reader.read(null, decoder);
        } catch (IOException e) {
            LOG.error("error while transform json event to LPevent class, event json= {}", json, e);
            throw e;
        }
        return dataaccessRoot;
    }

    /**
     * create generic record from json
     *
     * @param schemaWriterJson - the schema that the event was written with
     * @param json
     * @return
     */
    public static GenericRecord fromJsonToGeneric(String json, String schemaWriterJson) throws IOException {
        Schema schemaWriter = new org.apache.avro.Schema.Parser().parse(schemaWriterJson);
        GenericRecord dataaccessRootGeneric = null;

        try {
            Decoder decoder = DecoderFactory.get().jsonDecoder(schemaWriter, json);
            DatumReader<GenericRecord> reader = new GenericDatumReader<GenericRecord>(schemaWriter);

            dataaccessRootGeneric = reader.read(null, decoder);
        } catch (IOException e) {
            LOG.error("error while transform json event to LPevent class, event json= {}", json, e);
            throw e;
        }
        return dataaccessRootGeneric;
    }

}
