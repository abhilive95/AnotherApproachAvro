package com.centurylink.liveperson.model;

import io.swagger.annotations.ApiModel;

@ApiModel(description="A ChatServices Error Response Description.")
public class ErrorResponse {
	
	private ErrorMessage error;
	
	
	public ErrorMessage getError() {
		return error;
	}
	
	
	public void setError(ErrorMessage error) {
		this.error = error;
	}

}
