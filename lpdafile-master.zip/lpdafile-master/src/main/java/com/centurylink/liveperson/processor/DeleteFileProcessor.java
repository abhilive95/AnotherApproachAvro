package com.centurylink.liveperson.processor;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class DeleteFileProcessor implements Processor {

	@Override
	public void process(Exchange ex) throws Exception {

		String dir = System.getenv("TMPDIR")+"processed";
		System.out.println("directory to be deleted-----"+dir);

		deleteDirectory(new File(dir));

		/*
		 * 
		 * try { String fileName = ex.getProperty("fileName").toString(); String
		 * fileToDelete = System.getenv("TMPDIR") +
		 * "AgentActivity\\" + fileName + ".json";
		 * System.out.println("fileToDelete--------" + fileToDelete);
		 * 
		 * File file = new File(fileToDelete);
		 * 
		 * System.out.println("can be written--------" + file.canWrite());
		 * 
		 * if (file.canWrite()) {
		 * 
		 * System.out.println("delete file------" + file.delete());
		 * 
		 * } else {
		 * 
		 * System.out.println("failed to delete the file---------");
		 * 
		 * }
		 * 
		 * 
		 * if (!file.delete()) { throw new IOException(
		 * "Failed to delete the file because: " +
		 * getReasonForFileDeletionFailureInPlainEnglish(file)); }
		 * 
		 * 
		 * } catch (Exception e) { System.out.println("failed to delete");
		 * 
		 * e.printStackTrace(); }
		 * 
		 */}

	public static boolean deleteDirectory(File dir) {
		if (dir.isDirectory()) {
			File[] children = dir.listFiles();
			for (int i = 0; i < children.length; i++) {
				if(!children[i].isDirectory()) {
					
					System.out.println("file to be deleted-----"+children[i]);
					boolean success = children[i].delete();
					System.out.println("isDeleetd------"+success);
					if (!success) {
						return false;
					}
					
				}
				
			}
		} // either file or an empty directory
		System.out.println("removing file or directory : " + dir.getName());
		return true;
		
		/*
		if (dir.isDirectory()) {
			File[] children = dir.listFiles();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDirectory(children[i]);
				if (!success) {
					return false;
				}
			}
		} // either file or an empty directory
		System.out.println("removing file or directory : " + dir.getName());
		return dir.delete();
	*/}

	

}
