package com.centurylink.liveperson.route;

import java.io.FileNotFoundException;
import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.file.GenericFileOperationFailedException;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.apache.commons.httpclient.ConnectTimeoutException;
import org.apache.commons.httpclient.NoHttpResponseException;
import org.springframework.stereotype.Component;

import com.centurylink.liveperson.processor.AgentActivityGzipProcessor;
import com.centurylink.liveperson.processor.EngagementGzipProcessor;
import com.centurylink.liveperson.processor.Http500InternalServerErrorProcessor;
import com.centurylink.liveperson.processor.LiveEngageFileProcessor;
import com.centurylink.liveperson.processor.LogEventProcessor;
import com.centurylink.liveperson.processor.RetryLogEventProcessor;
import com.centurylink.liveperson.processor.WebSessionGzipProcessor;
import com.centurylink.liveperson.security.OAuthSignatureProcessor;
import com.centurylink.liveperson.utility.EnvPropertyUtil;
import com.centurylink.liveperson.utility.LpdaFileConstants;

@Component
public class LivePersonRouteBuilder extends RouteBuilder {

	@SuppressWarnings("unchecked")
	@Override
	public void configure() throws Exception {

		// turn camel tracing on or off
		getContext().setTracing(true);

		// global exception handling for invalid requests

		onException(SocketTimeoutException.class).handled(true)
				.maximumRedeliveries(EnvPropertyUtil.getMaximumRetriesCount())
				.delayPattern(EnvPropertyUtil.getRetryDelayPattern())
				.log("Retry_file_failed=${property.fileName}")
				.onRedelivery(new RetryLogEventProcessor()).retryAttemptedLogLevel(LoggingLevel.WARN)
				.log("Retry_value_failed=${property.retryEvent}").log(LoggingLevel.ERROR, "${exception.stacktrace}")
				.setProperty("exceptionType", constant(LpdaFileConstants.SOCKET_TIMEOUT_EXCEPTION))
				.process(new LogEventProcessor());
		
		onException(NoHttpResponseException.class, ConnectTimeoutException.class).handled(true)
				.maximumRedeliveries(EnvPropertyUtil.getMaximumRedeliveriesCount())
				.onRedelivery(new RetryLogEventProcessor()).retryAttemptedLogLevel(LoggingLevel.WARN)
				.log("${property.retryEvent}").log(LoggingLevel.ERROR, "${exception.stacktrace}")
				.setProperty("exceptionType", constant(LpdaFileConstants.TRANSPORT_EXCEPTION))
				.process(new LogEventProcessor());

		onException(FileNotFoundException.class).handled(true)
				.maximumRedeliveries(EnvPropertyUtil.getMaximumRedeliveriesCount())
				.onRedelivery(new RetryLogEventProcessor()).retryAttemptedLogLevel(LoggingLevel.WARN)
				.log("${property.retryEvent}").log(LoggingLevel.ERROR, "${exception.stacktrace}")
				.setProperty("exceptionType", constant(LpdaFileConstants.FILENOTFOUND_EXCEPTION))
				.process(new LogEventProcessor());

		onException(GenericFileOperationFailedException.class).handled(true)
				.maximumRedeliveries(EnvPropertyUtil.getMaximumRedeliveriesCount())
				.onRedelivery(new RetryLogEventProcessor()).retryAttemptedLogLevel(LoggingLevel.WARN)
				.log("${property.retryEvent}").log(LoggingLevel.ERROR, "${exception.stacktrace}")
				.setProperty("exceptionType", constant(LpdaFileConstants.FILE_OPERATIONFAILED_EXCEPTION))
				.process(new LogEventProcessor());
		
		onException(UnknownHostException.class, ConnectException.class, NoRouteToHostException.class).handled(true)
				.maximumRedeliveries(EnvPropertyUtil.getMaximumRedeliveriesCount())
				.onRedelivery(new RetryLogEventProcessor()).retryAttemptedLogLevel(LoggingLevel.WARN)
				.log("retry# ${property.retryEvent}").log(LoggingLevel.ERROR, "${exception.stacktrace}")
				.setProperty("exceptionType", constant(LpdaFileConstants.FILE_SOCKET_EXCEPTION))
				.process(new LogEventProcessor());
		

		onException(OutOfMemoryError.class).handled(true).log(LoggingLevel.WARN, "${exception.stacktrace}")
				.setProperty("exceptionType", constant(LpdaFileConstants.OUTOFMEMORY_EXCEPTION))
				.process(new LogEventProcessor());

		onException(HttpOperationFailedException.class).handled(true).log(LoggingLevel.WARN, "${exception.stacktrace}")
				.setProperty("exceptionType", constant(LpdaFileConstants.HTTP_OPERATIONFAILED_EXCEPTION))
				.process(new LogEventProcessor());

		onException(Exception.class).handled(true).log(LoggingLevel.ERROR, "${exception.stacktrace}")
				.process(new Http500InternalServerErrorProcessor()).end();
		
				
		// for AgentActivity
		
		from("activemq:{{env:AGENTACTIVITY_QUEUE_NAME}}?destination.consumer.prefetchSize={{env:AGENTACTIVITY_PRE_FETCH_SIZE}}")
				.throttle(EnvPropertyUtil.getThrottleLongProperty("agentActivity", 1))
				.timePeriodMillis(EnvPropertyUtil.getTimePeriodLongProperty("agentActivity", 30000))
				.process(new LiveEngageFileProcessor()).setHeader(Exchange.HTTP_METHOD, simple("GET", String.class))
				.setHeader(Exchange.HTTP_URI, simple("${property.fileURI}", String.class))
				.process(new OAuthSignatureProcessor())
				.to("https://dummy.com?httpClient.soTimeout={{env:AGENTACTIVITY_SO_TIMEOUT}}") // this actually calls out to LiveEngage even though it says dummy
				.setHeader("CamelFileName", simple("agentActivity/${property.fileName}")).to("file://inbox").end();

		from("file://inbox/agentActivity?delete=true")
				//.process(new AgentActivityGzipProcessor()).to("direct:sendToBaseCamp")
				//.multicast().to("seda:sendToDataLake", "seda:processAgentActivity")
				//.to("seda:sendToDataLake")
				.to("direct:directSendToDataLake")
				.to("seda:processAgentActivity")
				.end();
		
		from("seda:processAgentActivity").process(new AgentActivityGzipProcessor()).to("direct:sendToBaseCamp").end();
		 

		// for WebSession

		from("activemq:{{env:WEBSESSION_QUEUE_NAME}}?destination.consumer.prefetchSize={{env:WEBSESSION_PRE_FETCH_SIZE}}")
				.throttle(EnvPropertyUtil.getThrottleLongProperty("webSession", 1))
				.timePeriodMillis(EnvPropertyUtil.getTimePeriodLongProperty("webSession", 60000))
				.process(new LiveEngageFileProcessor()).setHeader(Exchange.HTTP_METHOD, simple("GET", String.class))
				.setHeader(Exchange.HTTP_URI, simple("${property.fileURI}", String.class))
				.process(new OAuthSignatureProcessor())
				.to("https://dummy.com?httpClient.soTimeout={{env:WEBSESSION_SO_TIMEOUT}}") // this actually calls out to LiveEngage even though it says dummy
				.setHeader("CamelFileName", simple("webSession/${property.fileName}")).to("file://inbox").end();

		from("file://inbox/webSession?delete=true")
				//.process(new WebSessionGzipProcessor()).to("direct:sendToBaseCamp")
				//.multicast().to("seda:sendToDataLake", "seda:processWebSession")
				/*.onCompletion()
		        .to("seda:sendToDataLake")
				.end()
				.to("seda:processWebSession")
				.end(); */
				//.multicast().to("seda:sendToDataLake", "seda:processWebSession")
		
			    //.to("seda:sendToDataLake")
				.to("direct:directSendToDataLake")
				.to("seda:processWebSession")
				.end();

		from("seda:processWebSession").process(new WebSessionGzipProcessor()).to("direct:sendToBaseCamp").end();
		
		
		// for Engagement
		
		from("activemq:{{env:ENGAGEMENT_QUEUE_NAME}}?destination.consumer.prefetchSize={{env:ENGAGEMENT_PRE_FETCH_SIZE}}")
				.throttle(EnvPropertyUtil.getThrottleLongProperty("engagement", 1))
				.timePeriodMillis(EnvPropertyUtil.getTimePeriodLongProperty("engagement", 45000))
				.process(new LiveEngageFileProcessor()).setHeader(Exchange.HTTP_METHOD, simple("GET", String.class))
				.setHeader(Exchange.HTTP_URI, simple("${property.fileURI}", String.class))
				.process(new OAuthSignatureProcessor())
				.to("https://dummy.com?httpClient.soTimeout={{env:ENGAGEMENT_SO_TIMEOUT}}") // this actually calls out to LiveEngage even though it says dummy
				.setHeader("CamelFileName", simple("engagement/${property.fileName}")).to("file://inbox").end();

		from("file://inbox/engagement?delete=true")
				//.process(new EngagementGzipProcessor()).to("direct:sendToBaseCamp")
				//.multicast().to("seda:sendToDataLake", "seda:processEngagement")
				//.to("seda:sendToDataLake")
				.to("direct:directSendToDataLake")
				.to("seda:processEngagement")
				.end();
		
		from("seda:processEngagement").process(new EngagementGzipProcessor()).to("direct:sendToBaseCamp").end();
		
		/*
		 * 
		 * route to handle the call which will process anf send the missing files to datalake.
		 * this call will be specific to datalake only 
		 */
		
		from("activemq:{{env:DATALAKE_QUEUE_NAME}}?destination.consumer.prefetchSize={{env:DATALAKE_PRE_FETCH_SIZE}}")
				.throttle(EnvPropertyUtil.getThrottleLongProperty("dataLake", 1))
				.timePeriodMillis(EnvPropertyUtil.getTimePeriodLongProperty("dataLake", 45000))
				.process(new LiveEngageFileProcessor()).setHeader(Exchange.HTTP_METHOD, simple("GET", String.class))
				.setHeader(Exchange.HTTP_URI, simple("${property.fileURI}", String.class))
				.process(new OAuthSignatureProcessor())
				.to("https://dummy.com?httpClient.soTimeout={{env:DATALAKE_SO_TIMEOUT}}") // this actually calls out to
																							// LiveEngage even though it
																							// says dummy
				.setHeader("CamelFileName", simple("dataLake/${property.fileName}")).to("file://inbox").end();
		
		
		/*
		 * ending of the route 
		 */
		
		from("file://inbox/dataLake?delete=true")
				// .to("seda:sendToDataLake")
				.to("direct:directSendToDataLake").end();
		 
		
		from("direct:directSendToDataLake")

				.choice().when(header("CamelFileName").isNotNull())
				//.to("file:c:\\data\\inbox\\gzip")
				.to("sftp://{{lcdl.user}}@{{lcdl.host}}{{lcdl.path}}?{{lcdl.option}}").otherwise()
				//.to("file:c:\\data\\inbox\\gzip\\?fileName=${property.fileName}")
				.to("sftp://{{lcdl.user}}@{{lcdl.host}}{{lcdl.path}}?{{lcdl.option}}&fileName=${property.fileName}")
				.end();
		
		
		from("direct:sendToBaseCamp")
			    //.to("file:c:\\data\\inbox\\csv\\?fileName=${property.fileName}.csv")
			    .to("sftp://{{sftp.user}}@{{sftp.host}}{{sftp.path}}?{{sftp.option}}&fileName=${property.fileName}.csv")
				.log(LoggingLevel.INFO, "fileName_sent=${property.fileName}.csv").end();

	}

}