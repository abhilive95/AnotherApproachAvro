package com.centurylink.liveperson.exception;

public class InvalidJwtException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidJwtException(String message) {
		super(message);

	}

}
