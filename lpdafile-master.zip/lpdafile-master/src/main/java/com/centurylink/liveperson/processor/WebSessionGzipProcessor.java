package com.centurylink.liveperson.processor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


public class WebSessionGzipProcessor implements Processor {
	
	private static Logger logger = Logger.getLogger(WebSessionGzipProcessor.class);
	private static ObjectMapper mapper = new ObjectMapper();

	@Override
	public void process(Exchange ex) throws Exception {

		File file = ex.getIn().getBody(File.class);
		ex.setProperty("fileName", file.getName());

		BufferedReader in = new BufferedReader(new InputStreamReader(
		        new GZIPInputStream(new FileInputStream(file))));
				
		int recordCount = 0;
		int outputCount = 0;
		
		String content;
		StringBuilder stringBuilder = new StringBuilder("VisitorId, OrderId\n");
		
		while ((content = in.readLine()) != null) {
			recordCount++;
			JsonNode dataAccessRoot = mapper.readTree(content);
			JsonNode datas = dataAccessRoot.path("recordCollection").path("array");
			if (datas.isArray()) {
				for (JsonNode data : datas) {												
					JsonNode body = data.path("body");
					if (body.has("com.liveperson.dataaccess.WebSessionEngAttrsData")) {							
						JsonNode webSessionEngAttrsData = body.path("com.liveperson.dataaccess.WebSessionEngAttrsData");
						String visitorId = webSessionEngAttrsData.path("header").path("com.liveperson.dataaccess.VisitorHeader") 
								.path("visitorId").path("string").asText();														
						if (webSessionEngAttrsData.has("engagementAttributes")) {
							JsonNode engagementAttributes = webSessionEngAttrsData.path("engagementAttributes").path("array");
							if (engagementAttributes.isArray()) {
								for (JsonNode engagementAttribute : engagementAttributes) {
									if (engagementAttribute.path("data").has("com.liveperson.dataaccess.Purchase")) {
										String orderId = engagementAttribute.path("data").path("com.liveperson.dataaccess.Purchase")
												.path("orderId").path("string").asText();
										logger.info("WebSession_OutRec VisitorId=" + visitorId + " OrderId=" + orderId);
										outputCount++;
										stringBuilder.append(ObjectUtils.toString(visitorId) + "," + ObjectUtils.toString(orderId) + "\n");
									}
								}
							}
						}
					}
				}
			}
		}
		
		in.close();
		logger.info("WebSession_RecordCount=" + recordCount);
		logger.info("WebSession_OutputCount=" + outputCount);
		ex.getOut().setBody(stringBuilder.toString());
		
	}

}
