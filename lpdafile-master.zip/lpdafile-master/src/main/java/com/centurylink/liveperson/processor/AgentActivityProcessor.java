package com.centurylink.liveperson.processor;

import java.io.File;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import com.liveperson.dataaccess.AgentActivityData;
import com.liveperson.dataaccess.AgentSessionData;
import com.liveperson.dataaccess.Data;
import com.liveperson.dataaccess.DataaccessRoot;

public class AgentActivityProcessor implements Processor {
	
	private static Logger logger = Logger.getLogger(AgentActivityProcessor.class);

	@Override
	public void process(Exchange ex) throws Exception {

		File body = ex.getIn().getBody(File.class);
		ex.setProperty("fileName", body.getName());

		String schemaPath = AgentActivityProcessor.class.getResource("/avro/liveperson.avsc").getPath();
		String schemaContent = FileUtils.readFileToString(new File(schemaPath), Charset.defaultCharset());
		
		LineIterator iter = FileUtils.lineIterator(body);
		StringBuilder stringBuilder = new StringBuilder("AgentSessionId, AgentId, AgentEmployeeId\n");
		int recordCount = 0;

		while (iter.hasNext()) {
			recordCount++;
			DataaccessRoot dataaccessRootSpecific = DASchemaUtils.fromJsonToSpecific(iter.next(), schemaContent);
			List<Data> datas = dataaccessRootSpecific.getRecordCollection();
			for (Iterator<Data> i = datas.iterator(); i.hasNext();) {
				Data data = (Data) i.next();
				AgentActivityData agentActivityData = (AgentActivityData) data.getBody();
				String agentSessionId = agentActivityData.getHeader().getAgentSessionId().toString();
				List<AgentSessionData> sessionData = agentActivityData.getAgentSessionsData();

				for (Iterator<AgentSessionData> sData = sessionData.iterator(); sData.hasNext();) {
					AgentSessionData agentSessionData = sData.next();
//					System.out
//							.println("AgentSessionId: " + agentSessionId + ", AgentId: " + agentSessionData.getAgentID()
//									+ ", AgentEmployeeId: " + agentSessionData.getAgentEmployeeId());
					stringBuilder.append(ObjectUtils.toString(agentSessionId) + "," + ObjectUtils.toString(agentSessionData.getAgentID()) + ","
							+ ObjectUtils.toString(agentSessionData.getAgentEmployeeId()) + "\n");

				}
			}
		}
		
		iter.close();
		logger.info("AgentActivity.RecordCount=" + recordCount);
		ex.getOut().setBody(stringBuilder.toString());

	}

}