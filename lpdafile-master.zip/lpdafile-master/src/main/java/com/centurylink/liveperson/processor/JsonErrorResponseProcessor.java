package com.centurylink.liveperson.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import org.json.JSONObject;

import com.centurylink.liveperson.model.ErrorResponse;

public class JsonErrorResponseProcessor implements Processor {
	
	public void process(Exchange exch) throws Exception {
		
		ErrorResponse response = exch.getProperty("errorResponse", ErrorResponse.class);
		
		JSONObject jsonResponse = new JSONObject();
    	JSONObject responseInfo = new JSONObject();
    	
    	responseInfo.put("time", response.getError().getTime());
		responseInfo.put("message", response.getError().getMessage());
		
		jsonResponse.put("error", responseInfo);
		
		exch.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, exch.getProperty("statusCode", 500));
		exch.getOut().setHeader(Exchange.CONTENT_TYPE, "application/json");
		exch.getOut().setBody(jsonResponse.toString());
		
	}
	
}
