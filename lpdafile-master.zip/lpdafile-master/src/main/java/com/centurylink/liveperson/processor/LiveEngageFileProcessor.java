package com.centurylink.liveperson.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.json.JSONObject;

public class LiveEngageFileProcessor implements Processor {

	@Override
	public void process(Exchange ex) throws Exception {

		String bodyMessage = ex.getIn().getBody(String.class);

		try {

			JSONObject jsonFile = new JSONObject(bodyMessage);
			String fileName = jsonFile.getString("name");
			String fileURI = jsonFile.getString("href");

			ex.setProperty("fileName", fileName);
			ex.setProperty("fileURI", fileURI);

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
