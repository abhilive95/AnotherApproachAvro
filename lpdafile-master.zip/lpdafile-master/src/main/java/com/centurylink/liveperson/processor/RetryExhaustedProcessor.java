package com.centurylink.liveperson.processor;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.hyperion.sentry.SentryAlarm;
import com.centurylink.liveperson.model.ErrorMessage;
import com.centurylink.liveperson.model.ErrorResponse;

import sentry.event.Severity;

public class RetryExhaustedProcessor implements Processor {

	public void process(Exchange ex) throws Exception {

		
//		String expType = ex.getProperty("exceptionType").toString();
//		String eventMessage = "";
//
//		switch (expType) {
//		case "transportException":
//			eventMessage = "Maximum retry has been exhausted!!!";
//			break;
//		case "outOfMemory":
//			eventMessage = "Not enough memory to process the request!!!";
//			break;
//		default:
//			eventMessage = "Unknown Exception";
//			break;
//		}

		SentryAlarm.sendEvent(Severity.MAJOR, "ChatSvcs", "lpdafile", 4509, "LivePersonRouteBuilder", "Maximum retries had been reached", "");

	}

}
