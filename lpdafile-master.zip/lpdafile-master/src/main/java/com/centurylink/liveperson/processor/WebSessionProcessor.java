package com.centurylink.liveperson.processor;

import java.io.File;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import com.liveperson.dataaccess.Data;
import com.liveperson.dataaccess.DataaccessRoot;
import com.liveperson.dataaccess.EngagementAttribute;

import com.liveperson.dataaccess.Purchase;
import com.liveperson.dataaccess.WebSessionEngAttrsData;

public class WebSessionProcessor implements Processor {
	
	private static Logger logger = Logger.getLogger(WebSessionProcessor.class);

	public void process(Exchange ex) throws Exception {
				
		File body = ex.getIn().getBody(File.class);
		ex.setProperty("fileName", body.getName());
		
		String schemaPath = WebSessionProcessor.class.getResource("/avro/liveperson.avsc").getPath();
		String schemaContent = FileUtils.readFileToString(new File(schemaPath), Charset.defaultCharset());

		LineIterator iter = FileUtils.lineIterator(body);
		StringBuilder stringBuilder = new StringBuilder("VisitorId, OrderId\n");
		int recordCount = 0;

		while (iter.hasNext()) {
			recordCount++;
			DataaccessRoot dataaccessRootSpecific = DASchemaUtils.fromJsonToSpecific(iter.next(), schemaContent);
			List<Data> datas = dataaccessRootSpecific.getRecordCollection();
			for (Iterator<Data> i = datas.iterator(); i.hasNext();) {
				Data data = (Data) i.next();
				Object obj = data.getBody();
				if (obj instanceof WebSessionEngAttrsData) {
					WebSessionEngAttrsData webSessionEngAttrsData = (WebSessionEngAttrsData) obj;
					String visitorId = webSessionEngAttrsData.getHeader().getVisitorId().toString();
					//String visit_Id = webSessionEngAttrsData.getHeader().getVisitId().toString();
					List<EngagementAttribute> engagementAttributes = webSessionEngAttrsData.getEngagementAttributes();
					for (Iterator<EngagementAttribute> j = engagementAttributes.iterator(); j.hasNext();) {
						EngagementAttribute engagementAttribute = (EngagementAttribute) j.next();
						Object eaObj = engagementAttribute.getData();
						if (eaObj instanceof Purchase) {
							Purchase purchase = (Purchase) eaObj;
//							System.out.println("Visit id: " + visit_Id + "Visitor Id: " + visitorId + ", Order Id: "
//									+ purchase.getOrderId());
							//stringBuilder.append(visit_Id + "," + visitorId + "," + purchase.getOrderId() + "\n");
							stringBuilder.append(ObjectUtils.toString(visitorId) + "," + ObjectUtils.toString(purchase.getOrderId()) + "\n");

						}
					}
				}
			}
		}
		
		iter.close();
		logger.info("WebSession.RecordCount=" + recordCount);
		ex.getOut().setBody(stringBuilder.toString());

	}

}
