package com.centurylink.liveperson.security;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;


public class OAuthSignatureProcessor implements Processor {

	// https://oauth.net/core/1.0/#signing_process
	// https://dev.twitter.com/oauth/overview/creating-signatures
	// https://developers.liveperson.com/guides-gettingstarted.html
	// https://developers.liveperson.com/data-data-access-overview.html
	// https://tectonictech.wordpress.com/2014/08/19/how-to-generate-oauth-signature-for-twitter-in-core-java/ SOLUTION BASED ON THIS ARTICLE
	
	// get our Live Person OAuth 1.0 values from the runtime environment
    private String consumerKey = System.getenv("CONSUMER_KEY");
    private String consumerSecret = System.getenv("CONSUMER_SECRET");
    private String token= System.getenv("TOKEN");
    private String tokenSecret = System.getenv("TOKEN_SECRET");
    
    private static final String HMAC_SHA1 = "HmacSHA1";
 

    public void process(Exchange ex) throws Exception {
		
		String nonce =  "" + (int) (Math.random() * 100000000);
		String timeStamp = "" + (System.currentTimeMillis() / 1000);
		String parametersStr = createParametersStr(
				nonce, 
				timeStamp, 
				ex.getIn().getHeader("startTime", String.class), 
				ex.getIn().getHeader("endTime", String.class),
				ex.getIn().getHeader("schemaId", String.class));
		String httpMethod = ex.getIn().getHeader(Exchange.HTTP_METHOD, String.class);
		String baseURL = ex.getIn().getHeader(Exchange.HTTP_URI, String.class);
		String signatureBaseStr = createSignatureBaseStr(httpMethod, baseURL, parametersStr);
		
		String oauth = "OAuth oauth_consumer_key=\"" + consumerKey;
		oauth += "\", oauth_token=\"" + token;
		oauth += "\", oauth_signature_method=\"HMAC-SHA1";
		oauth += "\", oauth_timestamp=\"" + timeStamp + "\"";
		oauth += ", oauth_nonce=\"" + nonce;
		oauth += "\", oauth_version=\"1.0\"";		
		oauth += ", oauth_signature=\"" + generateSignature(signatureBaseStr, consumerSecret, tokenSecret) + "\"";

		ex.getIn().setHeader("Authorization", oauth);
	}
    
	private String createParametersStr(String nonce, String timeStamp, String startTime, String endTime, String schemaId) {
		
		
    	// build a list of all the parameters we need to include in the signature base string
		List<NameValuePair> qparams = new ArrayList<NameValuePair>();
		if(endTime != null){
			qparams.add(new BasicNameValuePair("endTime", endTime));
		}
        qparams.add(new BasicNameValuePair("oauth_consumer_key", consumerKey));
        qparams.add(new BasicNameValuePair("oauth_nonce", nonce));
        qparams.add(new BasicNameValuePair("oauth_signature_method", "HMAC-SHA1"));
        qparams.add(new BasicNameValuePair("oauth_timestamp", timeStamp));
        qparams.add(new BasicNameValuePair("oauth_token", token));
        qparams.add(new BasicNameValuePair("oauth_version", "1.0"));
		if(schemaId != null){
			qparams.add(new BasicNameValuePair("schemaId", schemaId));
		}
		if(startTime != null){
			qparams.add(new BasicNameValuePair("startTime", startTime));
		}
        
        // create a list of percent encoded parameters
        List<NameValuePair> encqparams = new ArrayList<NameValuePair>();
        for (Iterator<NameValuePair> i = qparams.iterator(); i.hasNext();) {
			NameValuePair nameValuePair = (NameValuePair) i.next();
			String encKey = encode(nameValuePair.getName());
			String encValue = encode(nameValuePair.getValue());
			encqparams.add(new BasicNameValuePair(encKey, encValue));
		}
        
        // sort the percent encoded parameters by key name
        Collections.sort(encqparams, new SortNameValuePairByKey());

        // create the parameters string
        StringBuilder sb = new StringBuilder();
       
        for (Iterator<NameValuePair> j = encqparams.iterator(); j.hasNext();) {
			NameValuePair nameValuePair = (NameValuePair) j.next();
			sb.append(nameValuePair.getName());
			sb.append("=");
			sb.append(nameValuePair.getValue());
			if(j.hasNext()) {
				sb.append("&");
			}
		}
	
        System.out.println("PARAMETERS: " + sb.toString());
		return sb.toString();
	}

	
	private String createSignatureBaseStr(String httpMethod, String baseURL, String parameters) {
		
		StringBuilder sb = new StringBuilder();
		sb.append(httpMethod.toUpperCase());
		sb.append("&");
		sb.append(encode(baseURL));
		sb.append("&");
		sb.append(encode(parameters));
		
		return sb.toString();
	}
	
	
//	private String createSigningKey(String consumerSecret, String tokenSecret) {
//		
//		StringBuilder sb = new StringBuilder();
//		sb.append(consumerSecret);
//		
//		if(tokenSecret != null) {
//			sb.append("&");
//			sb.append(tokenSecret);
//		} else {
//			sb.append("&");
//		}
//	
//		return sb.toString();
//	}	
	
	
	/**
	    * percentage encoding
	    *
	    * @return A encoded string
	    */
	 private String encode(String value) {  
	     String encoded = "";  
	     try {  
	       encoded = URLEncoder.encode(value, "UTF-8");  
	     } catch (Exception e) {  
	       e.printStackTrace();  
	     }  
	      String sb = "";  
	     char focus;  
	     for (int i = 0; i < encoded.length(); i++) {  
	       focus = encoded.charAt(i);  
	       if (focus == '*') {  
	         sb += "%2A"; 
	       } else if (focus == '+') {  
	         sb += "%20";
	       } else if (focus == '%' && i + 1 < encoded.length()  
	           && encoded.charAt(i + 1) == '7' && encoded.charAt(i + 2) == 'E') {  
	         sb += '~';
	         i += 2;  
	       } else {  
	         sb += focus;
	       }  
	     }  
	     return sb.toString();  
	   }  
	 
	private String generateSignature(String signatueBaseStr, String oAuthConsumerSecret, String oAuthTokenSecret) {  
	     byte[] byteHMAC = null;  
	     try {  
	       Mac mac = Mac.getInstance(HMAC_SHA1);  
	       SecretKeySpec spec;  
	       if (null == oAuthTokenSecret) {  
	         String signingKey = encode(oAuthConsumerSecret) + '&';  
	         spec = new SecretKeySpec(signingKey.getBytes(), HMAC_SHA1);  
	       } else {  
	         String signingKey = encode(oAuthConsumerSecret) + '&' + encode(oAuthTokenSecret);  
	         spec = new SecretKeySpec(signingKey.getBytes(), HMAC_SHA1);  
	       }  
	       mac.init(spec);  
	       byteHMAC = mac.doFinal(signatueBaseStr.getBytes());  
	     } catch (Exception e) {  
	       e.printStackTrace();  
	     }  
	     
	     return Base64.encodeBase64String(byteHMAC);
	   }  
	
	class SortNameValuePairByKey implements Comparator<NameValuePair> {

		@Override
		public int compare(NameValuePair nvp1, NameValuePair nvp2) {
			return nvp1.getName().compareTo(nvp2.getName());
		}
		
		
	}
	
}
