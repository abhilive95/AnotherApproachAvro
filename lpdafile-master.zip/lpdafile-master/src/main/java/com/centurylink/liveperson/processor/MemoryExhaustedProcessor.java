package com.centurylink.liveperson.processor;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.liveperson.model.ErrorMessage;
import com.centurylink.liveperson.model.ErrorResponse;

public class MemoryExhaustedProcessor implements Processor {

	public void process(Exchange ex) throws Exception {
		
		ErrorResponse response = new ErrorResponse();
    	ErrorMessage message = new ErrorMessage();
    	
    	// The time can be use to search the logs for the exception information
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
    	Date date = new Date();
    	
    	message.setTime(sdf.format(date));
    	message.setMessage("Not enough memory to process the request");
    	
    	response.setError(message);
		
    	ex.setProperty("statusCode", "");
    	ex.setProperty("errorResponse", response);
		
	}

}
