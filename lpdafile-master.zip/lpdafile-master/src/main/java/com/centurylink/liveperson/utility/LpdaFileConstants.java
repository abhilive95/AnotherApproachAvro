package com.centurylink.liveperson.utility;

public interface LpdaFileConstants {

	String APP_NAME = "CHATSVCS";
	String SUBSYSTEM_NAME = "lpdafile";
	int DEFAULT_IDENTIFIER = 4500;
	int TRANSPORT_IDENTIFIER = 4501;
	int FILENOTFOUND_IDENTIFIER = 4502;
	int OUTOFMEMORY_IDENTIFIER = 4503;
	int HTTP_OPERATIONFAILED_IDENTIFIER = 4504;
	int IO_IDENTIFIER = 4505;
	int FILE_OPERATIONFAILED_IDENTIFIER = 4506;
	int FILE_SOCKET_EXCEPTION_IDENTIFIER = 4507;
	int SOCKET_TIMEOUT_EXCEPTION_IDENTIFIER = 4508;
	
	String TRANSPORT_EXCEPTION = "transportException";
	String FILENOTFOUND_EXCEPTION = "fileNotFound";
	String FILE_OPERATIONFAILED_EXCEPTION = "fileOperationFailed";
	String OUTOFMEMORY_EXCEPTION = "outOfMemory";
	String HTTP_OPERATIONFAILED_EXCEPTION = "httpOperationFailed";
	String IO_EXCEPTION = "ioException";
	String FILE_SOCKET_EXCEPTION = "ftpSocketexception";
	String SOCKET_TIMEOUT_EXCEPTION = "SocketTimeoutException";
	
	
}
