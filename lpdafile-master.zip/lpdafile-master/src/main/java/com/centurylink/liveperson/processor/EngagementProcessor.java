package com.centurylink.liveperson.processor;

import java.io.File;

import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import com.liveperson.dataaccess.Conversation;
import com.liveperson.dataaccess.Data;
import com.liveperson.dataaccess.DataaccessRoot;
import com.liveperson.dataaccess.EngagementData;

public class EngagementProcessor implements Processor {

	private static Logger logger = Logger.getLogger(EngagementProcessor.class);
	
	public void process(Exchange ex) throws Exception {
				
		File body = ex.getIn().getBody(File.class);
		ex.setProperty("fileName", body.getName());
		
		String schemaPath = EngagementProcessor.class.getResource("/avro/liveperson.avsc").getPath();
		String schemaContent = FileUtils.readFileToString(new File(schemaPath), Charset.defaultCharset());

		LineIterator iter = FileUtils.lineIterator(body);
		StringBuilder stringBuilder = new StringBuilder("VisitorId, AgentId\n");
		int recordCount = 0;
		
		while (iter.hasNext()) {
			recordCount++;
			DataaccessRoot dataaccessRootSpecific = DASchemaUtils.fromJsonToSpecific(iter.next(), schemaContent);
			List<Data> datas = dataaccessRootSpecific.getRecordCollection();
			for (Iterator<Data> i = datas.iterator(); i.hasNext();) {
				Data data = (Data) i.next();
				EngagementData engagementData = (EngagementData) data.getBody();
				String visitorId = engagementData.getHeader().getVisitorId().toString();
				List<Object> conversations = engagementData.getEngagements();
				for (Iterator<Object> j = conversations.iterator(); j.hasNext();) {
					Conversation conversation = (Conversation) j.next();
//					System.out.println("Visitor Id: " + visitorId + ", Agent Id: " + conversation.getAgentId());

					stringBuilder.append(ObjectUtils.toString(visitorId) + "," + ObjectUtils.toString(conversation.getAgentId()) + "\n");

				}
			}
		}

		iter.close();
		logger.info("Engagement.RecordCount=" + recordCount);
		ex.getOut().setBody(stringBuilder.toString());

	}

}
