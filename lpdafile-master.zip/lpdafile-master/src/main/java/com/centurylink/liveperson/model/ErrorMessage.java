package com.centurylink.liveperson.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="A ChatServices Error Message Description.")
public class ErrorMessage {

	private String time;
	private String message;
	
	
	@ApiModelProperty(value="The system time the error occurred", dataType="string", required=true)
	public String getTime() {
		return time;
	}
	
	public void setTime(String time) {
		this.time = time;
	}
	
	@ApiModelProperty(value="A short piece of information about the error", dataType="string", required=true)
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
}
