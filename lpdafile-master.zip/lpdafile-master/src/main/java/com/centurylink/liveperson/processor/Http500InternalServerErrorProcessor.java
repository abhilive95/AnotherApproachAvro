package com.centurylink.liveperson.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.hyperion.sentry.SentryAlarm;

import sentry.event.Severity;

public class Http500InternalServerErrorProcessor implements Processor {

	public void process(Exchange ex) throws Exception {
		
		SentryAlarm.sendEvent(Severity.CRITICAL, "ChatSvcs", "lpdafile", 4500, "LivePersonRouteBuilder", "Unexpected exception encountered", ""); 
		
	}

}
