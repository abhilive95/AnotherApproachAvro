package com.centurylink.liveperson.processor;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.apache.log4j.Logger;

import com.centurylink.liveperson.model.ErrorMessage;
import com.centurylink.liveperson.model.ErrorResponse;

public class HttpOperationFailedProcessor implements Processor {
	
	private static Logger logger = Logger.getLogger(HttpOperationFailedProcessor.class);

	public void process(Exchange exch) throws Exception {
		
		// Retrieve the exception from exchange property
		HttpOperationFailedException	hofe = exch.getProperty(Exchange.EXCEPTION_CAUGHT, HttpOperationFailedException.class);
		logger.error("LivePerson ErrorResponse: " + hofe.getResponseBody());
		   	
		ErrorResponse response = new ErrorResponse();
    	ErrorMessage message = new ErrorMessage();
    	
    	// The time can be use to search the logs for the exception information
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
    	Date date = new Date();
    	
    	message.setTime(sdf.format(date));
    	
    	int statusCode = hofe.getStatusCode();
    	    	
		switch(statusCode) {
			case 400:	message.setMessage("Failed to process request, please check all of the request arguments are valid");				
						break;				
			case 401:	message.setMessage("Unauthorized request");
						break;
			case 404:	message.setMessage("No Available Files");
						break;
			case 503:	message.setMessage("Service Unavailable");
						break;
			default: 	message.setMessage("Unknown Server Error");
						break;
		}
		
		response.setError(message);
		
		exch.setProperty("statusCode", statusCode);
		exch.setProperty("errorResponse", response);
				
	}

}
