package com.centurylink.liveperson.processor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


public class EngagementGzipProcessor implements Processor {

	private static Logger logger = Logger.getLogger(EngagementGzipProcessor.class);
	private static ObjectMapper mapper = new ObjectMapper();
	
	public void process(Exchange ex) throws Exception {
				
		File file = ex.getIn().getBody(File.class);
		ex.setProperty("fileName", file.getName());
		
		BufferedReader in = new BufferedReader(new InputStreamReader(
		        new GZIPInputStream(new FileInputStream(file))));
				
		int recordCount = 0;
		int outputCount = 0;
		
		String content;
		StringBuilder stringBuilder = new StringBuilder("VisitorId, AgentId\n");
		
		while ((content = in.readLine()) != null) {
			recordCount++;	
			JsonNode dataAccessRoot = mapper.readTree(content);
			JsonNode datas = dataAccessRoot.path("recordCollection").path("array");
			if (datas.isArray()) {
				for (JsonNode data : datas) {												
					JsonNode body = data.path("body");
					if (body.has("com.liveperson.dataaccess.EngagementData")) {
						JsonNode engagementData = body.path("com.liveperson.dataaccess.EngagementData");
						String visitorId = engagementData.path("header").path("com.liveperson.dataaccess.VisitorHeader")
								.path("visitorId").path("string").asText();
						if (engagementData.has("engagements")) {
							JsonNode engagements = engagementData.path("engagements").path("array");
							if (engagements.isArray()) {
								for (JsonNode engagement : engagements) {
									if (engagement.has("com.liveperson.dataaccess.Conversation")) {
										JsonNode conversation = engagement.path("com.liveperson.dataaccess.Conversation");
										String agentId = conversation.path("agentId").path("string").asText();
										logger.info("Engagement_OutRec VisitorId=" + visitorId + " AgentId=" + agentId);
										outputCount++;
										stringBuilder.append(ObjectUtils.toString(visitorId) + "," + ObjectUtils.toString(agentId) + "\n");
									}
								}
							}
						}
					}
				}
			}
		}
		
		in.close();
		logger.info("Engagement_RecordCount=" + recordCount);
		logger.info("Engagement_OutputCount=" + outputCount);
		ex.getOut().setBody(stringBuilder.toString());
	}

}
