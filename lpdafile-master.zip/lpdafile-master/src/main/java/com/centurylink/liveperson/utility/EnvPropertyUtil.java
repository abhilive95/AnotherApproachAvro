package com.centurylink.liveperson.utility;

public class EnvPropertyUtil {
	
	// lpdafile startup environment variables 
	private static long webSessionThrottle = Long.parseLong(System.getenv("WEBSESSION_THROTTLE"));
	private static long webSessionTimePeriod = Long.parseLong(System.getenv("WEBSESSION_TIME_PERIOD_MILLIS"));
	
	private static int maximumRedeliveriesCount = Integer.parseInt(System.getenv("MAXIMUM_REDELIVERIES_COUNT"));
	private static int maximumRetriesCount = Integer.parseInt(System.getenv("MAXIMUM_RETRIES_COUNT"));
	
	private static long engagementThrottle = Long.parseLong(System.getenv("ENGAGEMENT_THROTTLE"));
	private static long engagementTimePeriod = Long.parseLong(System.getenv("ENGAGEMENT_TIME_PERIOD_MILLIS"));
	
	private static long agentActivityThrottle = Long.parseLong(System.getenv("AGENTACTIVITY_THROTTLE"));
	private static long agentActivityTimePeriod = Long.parseLong(System.getenv("AGENTACTIVITY_TIME_PERIOD_MILLIS"));
	
	private static long dataLakeThrottle = Long.parseLong(System.getenv("DATALAKE_THROTTLE"));
	private static long dataLakeTimePeriod = Long.parseLong(System.getenv("DATALAKE_TIME_PERIOD_MILLIS"));
	
	private static String retryDelayPattern = System.getenv("RETRY_DELAY_PATTERN");
	
	/*
	 * https://developers.liveperson.com/guides-retry-policy.html
	 * Set groups of ranges using the following syntax: limit:delay;limit 2:delay 2;limit 3:delay 3
	 * limit = upper limit
	 * delay = in milliseconds
	 */
	public static String getRetryDelayPattern() {
		return retryDelayPattern;
	}
	
	public static int getMaximumRetriesCount() {
		return maximumRetriesCount;
	}
	
	public static int getMaximumRedeliveriesCount() {
		return maximumRedeliveriesCount;
	}
	
	public static long getThrottleLongProperty(String key, long defaultValue) {
		long result = 1;
		
		switch (key) {
		case "webSession":
			result = webSessionThrottle;
			break;
			
		case "engagement":
			result = engagementThrottle;
			break;
			
		case "agentActivity":
			result = agentActivityThrottle;
			break;
			
		case "dataLake":
			result = dataLakeThrottle;
			break;
			
		default:
			result = defaultValue;
			break;
		}
		
		return result;
	}
	
	
	public static long getTimePeriodLongProperty(String key, long defaultValue) {
		long result = 30000;
		
		switch (key) {
		case "webSession":
			result = webSessionTimePeriod;
			break;
			
		case "engagement":
			result = engagementTimePeriod;
			break;
			
		case "agentActivity":
			result = agentActivityTimePeriod;
			break;
			
		case "dataLake":
			result = dataLakeTimePeriod;
			break;
			
		default:
			result = defaultValue;
			break;
		}
		
		return result;
	}

}
