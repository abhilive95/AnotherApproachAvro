package com.centurylink.liveperson;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.servlet.CamelHttpTransportServlet;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.spring.boot.FatJarRouter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class Application extends FatJarRouter  {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    ServletRegistrationBean servletRegistrationBean() {
        ServletRegistrationBean servlet = new ServletRegistrationBean(
            new CamelHttpTransportServlet(), "/rest/*");
        servlet.setName("CamelServlet");
        return servlet;
    }

    @Component
    class RestApi extends RouteBuilder {

        @Override
        public void configure() {
            restConfiguration()
                .contextPath("/rest").apiContextPath("/api-doc")
                .apiProperty("api.title", "CenturyLink Unifying Principles")
                .apiProperty("api.version", "1.0")
                .apiProperty("api.description", "Spring Boot with Camel REST DSL example based on the concept of CenturyLink's Unifying Principles. This example also demonstrates the use of the camel-sql component to manage persistence in a database and bottom up Swagger file creation.")
                .apiProperty("api.contact.name", "Michael Hanes")
                .apiProperty("api.contact.email", "michael.hanes@centurylink.com")
                .apiProperty("api.contact.url", "http://collaboration.ad.qintra.com/BU/IT/scph/DigitalPlatformDev/AS/HAPI/SitePages/Home.aspx")
                .apiProperty("host", "localhost:8080")
                .apiProperty("cors", "true")
                .apiContextRouteId("doc-api")
                .bindingMode(RestBindingMode.json);
        }
    }
  
}