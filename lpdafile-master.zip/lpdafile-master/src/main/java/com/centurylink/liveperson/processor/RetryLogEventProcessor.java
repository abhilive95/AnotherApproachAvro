package com.centurylink.liveperson.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

public class RetryLogEventProcessor implements Processor {
	private static Logger logger = Logger.getLogger(RetryLogEventProcessor.class);

	@Override
	public void process(Exchange e) throws Exception {

		String loggingEvent = "Retryable error occured. Retrying ...#"
				+ e.getIn().getHeader(Exchange.REDELIVERY_COUNTER, Integer.class);
		logger.info("Retry_value=" + loggingEvent);
		e.setProperty("retryEvent", loggingEvent);

	}

}
