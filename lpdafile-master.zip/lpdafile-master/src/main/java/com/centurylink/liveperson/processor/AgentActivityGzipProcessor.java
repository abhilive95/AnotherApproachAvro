package com.centurylink.liveperson.processor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


public class AgentActivityGzipProcessor implements Processor {
	
	private static Logger logger = Logger.getLogger(AgentActivityGzipProcessor.class);
	private static ObjectMapper mapper = new ObjectMapper();

	@Override
	public void process(Exchange ex) throws Exception {

		File file = ex.getIn().getBody(File.class);
		ex.setProperty("fileName", file.getName());
		
		BufferedReader in = new BufferedReader(new InputStreamReader(
		        new GZIPInputStream(new FileInputStream(file))));
				
		int recordCount = 0;
		int outputCount = 0;
		
		String content;
		StringBuilder stringBuilder = new StringBuilder("AgentSessionId, AgentId, AgentEmployeeId\n");
		
		while ((content = in.readLine()) != null) {
			recordCount++;	
			JsonNode dataAccessRoot = mapper.readTree(content);
			JsonNode datas = dataAccessRoot.path("recordCollection").path("array");
			if (datas.isArray()) {
				for (JsonNode data : datas) {												
					JsonNode body = data.path("body");
					if (body.has("com.liveperson.dataaccess.AgentActivityData")) {	
						JsonNode agentActivityData = body.path("com.liveperson.dataaccess.AgentActivityData");
						String agentSessionId = agentActivityData.path("header").path("com.liveperson.dataaccess.AgentHeader")
								.path("agentSessionId").path("string").asText();
						if (agentActivityData.has("agentSessionsData")) {
							JsonNode agentSessionsData = agentActivityData.path("agentSessionsData").path("array");
							if (agentSessionsData.isArray()) {
								for (JsonNode agentSessionData : agentSessionsData) {
									String agentId = agentSessionData.path("agentID").path("long").asText();
									String agentEmployeeId = agentSessionData.path("agentEmployeeId").path("string").asText();
									logger.info("AgentActivity_OutRec AgentSessionId=" + agentSessionId + " AgentId=" + agentId 
											+ " AgentEmployeeId=" + agentEmployeeId);
									outputCount++;
									stringBuilder.append(ObjectUtils.toString(agentSessionId) + "," + ObjectUtils.toString(agentId) + ","
											+ ObjectUtils.toString(agentEmployeeId) + "\n");
								}
							}
						}
					}
				}
			}				
		}
				
		in.close();
		logger.info("AgentActivity_RecordCount=" + recordCount);
		logger.info("AgentActivity_OutputCount=" + outputCount);
		ex.getOut().setBody(stringBuilder.toString());
	}

}